﻿using CureWellDataAccessLayer;
using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            CureWellRepository c=new CureWellRepository();
            var y=   c.GetAllDoctors();
            foreach(var t in y)
            {
                Console.WriteLine(t.DoctorId);
            }
            Console.WriteLine("Hello World!");
        }
    }
}
