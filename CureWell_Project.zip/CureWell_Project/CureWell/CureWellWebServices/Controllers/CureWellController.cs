﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CureWellDataAccessLayer;
using AutoMapper;
using CureWellDataAccessLayer.Models;

namespace CureWellWebServices.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CureWellController : ControllerBase
    {
        #region Uncomment the below line
        private readonly IMapper _mapper;
        #endregion

        #region Constructor - Do not modify the signature
        public CureWellController(IMapper mapper)
        {
            //To Do: Implement appropriate logic
            _mapper = mapper;
        }
        #endregion

        #region GetAllDoctorSpecialization - Do not modify the signature
        
        public JsonResult GetAllDoctorSpecialization()
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic

            List<Models.DoctorSpecialization> dList = new List<Models.DoctorSpecialization>();
            try
            {
                var repository = new CureWellRepository();

                var doctorList = repository.GetAllDoctorSpecialization();
                if (doctorList != null)
                {
                    foreach (var doc in doctorList)
                    {
                        Models.DoctorSpecialization specObj = _mapper.Map<Models.DoctorSpecialization>(doc);
                        //var category = new Models.Categories
                        //{
                        //    CategoryId = catObj.CategoryId,
                        //    CategoryName = catObj.CategoryName,
                        //};
                        dList.Add(specObj);
                    }
                }
            }
            catch (Exception ex)
            {
                dList = null;
            }
            return new JsonResult(dList);
        }
        #endregion

        #region AddDoctorSpecialization- Do not modify the signature
        [HttpPost]
        public bool AddDoctorSpecialization(Models.DoctorSpecialization doctorSpecialization)
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
            var status = false;
            try
            {
                var repo = new CureWellRepository();
                status = repo.AddDoctorSpecialization(_mapper.Map<DoctorSpecialization>(doctorSpecialization));
                return status;

            }
            catch (Exception)
            {
                return status;

            }
        }
        #endregion


    }
}
