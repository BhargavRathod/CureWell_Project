﻿using CureWellMVCApp.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Net.Http;

namespace CureWellMVCApp.Controllers
{
    public class CureWellClientController : Controller
    {
        #region Uncomment the below line
        IConfiguration Configuration;
        #endregion

        #region Constructor - Do not modify the signature
        public CureWellClientController(IConfiguration configuration)
        {
            //To Do: Implement appropriate logic
            Configuration = configuration;
        }
        #endregion

        #region GetAllDoctorSpecialization-Do not modify the signature of the Action
        public ActionResult GetAllDoctorSpecialization()
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic

            try
            {
                ServiceRepository serviceObj = new ServiceRepository(Configuration);
                HttpResponseMessage message = serviceObj.GetResponse("api/CureWell/GetAllDoctorSpecialization");
                message.EnsureSuccessStatusCode();
                var dObj = message.Content.ReadAsAsync<Models.DoctorSpecialization>().Result;
                return View(dObj);
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
        #endregion

        #region Create-Do not modify the signature of the Action
        public ActionResult Create()
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
             try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        public ActionResult AddDoctorSpecialization(Models.DoctorSpecialization doctorSpecialization)
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
            try
            {
                ServiceRepository serviceObj = new ServiceRepository(Configuration);
                HttpResponseMessage message = serviceObj.PostRequest("api/CureWell/AddDoctorSpecialization", doctorSpecialization);
                message.EnsureSuccessStatusCode();
                if (message.Content.ReadAsAsync<bool>().Result)
                {
                    return View();
                }
                return View("Error");
            }
            catch
            {
                return View();
            }
        }
        #endregion
    }
}