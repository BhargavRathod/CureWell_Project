﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CureWellDataAccessLayer;
using CureWellDataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CureWellMVCApp.Controllers
{
    public class HospitalController : Controller
    {
        #region Uncomment the below lines
        private readonly CureWellContext _context;
        private readonly IMapper _mapper;
        CureWellRepository repObj;
        #endregion
            
        #region Constructor - Do not modify the signature
        public HospitalController(CureWellContext context, IMapper mapper)
        {
            //To Do: Implement appropriate logic            
            _context = context;
            repObj = new CureWellRepository(_context);
            _mapper = mapper;
        }
        #endregion
    

        #region GetAllDoctors-Do not modify the signature of the Action
        public ActionResult GetAllDoctors()
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
            try
            {
                var lstEntityDoctors = repObj.GetAllDoctors();
                List<Models.Doctor> lstDoctors = new List<Models.Doctor>();
                foreach (var doctor in lstEntityDoctors)
                {
                    lstDoctors.Add(_mapper.Map<Models.Doctor>(doctor));
                }
                return View(lstDoctors);
            }
            catch(Exception)
            {
                return View("Error");
            }
            
          
        }
        #endregion

        #region Details-Do not modify the signature of the Action
        // GET
        public ActionResult Details(Models.Doctor doctor)
        {
            try
            {
                var doctorList = repObj.GetDoctor(doctor.DoctorId);     
                return View(_mapper.Map<Models.Doctor> (doctorList));
            }
            catch (Exception)
            {
                throw;
            }
           
          
        }
        #endregion

        #region Edit-Do not modify the signature of the Action
        // GET
        public ActionResult Edit(Models.Doctor doctor)
        {
            try
            {
                return View();
            }
            catch (Exception)
            {
                return View("Error");
            }
            
        }

        // POST     
        public ActionResult UpdateDoctorDetails(Models.Doctor doctor)
        {
            try
            {
                bool status = false;
                if (ModelState.IsValid)
                {
                    try
                    {
                        status = repObj.UpdateDoctorDetails(_mapper.Map<Doctor>(doctor));
                        if (status)
                            return RedirectToAction("GetAllDoctors");
                        else
                            return View("UpdateDoctorDetails", doctor);
                    }
                    catch (Exception)
                    {
                        return View("UpdateDoctorDetails", doctor);
                    }
                }
                return View("UpdateDoctorDetails", doctor);
            }catch(Exception)
            {
                throw;
            }
        }
        #endregion

        #region Delete-Do not modify the signature of the Action
        // GET
        public ActionResult Delete(Models.Doctor doctor)
        {
            try
            {
                return View(doctor);
            }
            catch (Exception)
            {

               return View("Error");
            }
           
        }

        // POST
        public ActionResult DeleteDoctorDetails(int doctorId)
        {
            bool status = false;
            try
            {
                status = repObj.DeleteDoctorDetails(doctorId);
                if (status)
                    return RedirectToAction("GetAllDoctors");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
        #endregion
    }
}