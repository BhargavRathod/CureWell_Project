﻿using AutoMapper;
using CureWellDataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CureWellMVCApp.Repository
{
    public class CureWellMapper:Profile
    {
        public CureWellMapper()
        {
            //To do implement necessary logic
            CreateMap<Doctor, Models.Doctor>();
            CreateMap<Models.Doctor, Doctor>();
            CreateMap<Models.DoctorSpecialization, DoctorSpecialization>();
            CreateMap<DoctorSpecialization, Models.DoctorSpecialization>();
        }
    }
}
