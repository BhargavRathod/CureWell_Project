﻿//using CureWellDataAccessLayer.Models;
using CureWellDataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CureWellDataAccessLayer
{
    public class CureWellRepository
    {
        
        #region Uncomment the below line
        CureWellContext context;
        private readonly CureWellContext _context;
        #endregion

        #region Constructor - Do not modify the signature
        public CureWellRepository()
        {
            //To Do: Implement appropriate logic
            _context = new CureWellContext();
           
        }
        #endregion

        #region Constructor - Do not modify the signature
        public CureWellRepository(CureWellContext context)
        {
            //To Do: Implement appropriate logic
            _context = context;
        }
        #endregion

        #region GetAllDoctors - Do not modify the signature
        public List<Doctor> GetAllDoctors()
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
            List<Doctor> lstDoctors = null;
            try
            {
                lstDoctors = (from d in _context.Doctor
                               select d).ToList();
            }
            catch (Exception e)
            {
                lstDoctors = null;
            }
            return lstDoctors;
           
        }
        #endregion

        #region GetDoctor - Do not modify the signature
        public Doctor GetDoctor(int doctorId)
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
            Doctor doctor = new Doctor();
            try
            {
                doctor = (from d in _context.Doctor
                           where d.DoctorId.Equals(doctorId)
                           select d).FirstOrDefault();
            }
            catch (Exception)
            {
                doctor = null;
            }
            return doctor;
            
        }
        #endregion

        #region GetAllDoctorSpecialization - Do not modify the signature
        public List<DoctorSpecialization> GetAllDoctorSpecialization()
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
            List<DoctorSpecialization> lstDoctors = null;
            try
            {
                lstDoctors = (from d in _context.DoctorSpecialization
                              orderby d.DoctorId
                              select d).ToList();
            }
            catch (Exception e)
            {
                lstDoctors = null;
            }
            return lstDoctors;
           
        }
        #endregion

        #region AddDoctorSpecialization - Do not modify the signature
        public bool AddDoctorSpecialization(DoctorSpecialization doctorSpecialization)
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic

            bool status = false;
            try
            {
                DoctorSpecialization spec = new DoctorSpecialization();
                spec.DoctorId = doctorSpecialization.DoctorId;
                spec.SpecializationCode = doctorSpecialization.SpecializationCode;
                spec.SpecializationDate = doctorSpecialization.SpecializationDate;
                _context.DoctorSpecialization.Add(spec);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;

           
        }
        #endregion

        #region UpdateDoctorDetails - Do not modify the signature
        public bool UpdateDoctorDetails(Doctor doct)
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
            bool status = false;
            try
            {
                var doctor = (from d in _context.Doctor
                               where d.DoctorId == doct.DoctorId
                               select d).FirstOrDefault<Doctor>();
                if (doctor != null)
                {
                    doctor.DoctorId = doct.DoctorId;
                    doctor.DoctorName = doct.DoctorName;
                   _context.SaveChanges();
                    status = true;
                }
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }
        #endregion

        #region DeleteDoctorDetails - Do not modify the signature
        public bool DeleteDoctorDetails(int doctorId)
        {
            //To Do: Implement appropriate logic and change the return statement as per your logic
            bool status = false;
            try
            {
                var doctor = (from d in _context.Doctor
                               where d.DoctorId == doctorId
                               select d).FirstOrDefault<Doctor>();
                //var doctor = _context.Doctor.Find(doctorId);
                _context.Doctor.Remove(doctor);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        #endregion
        
    }
}
